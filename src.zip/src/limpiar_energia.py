import pandas as pd
from pathlib import Path


# =========================
# CONFIGURACIÓN DE RUTAS
# =========================
BASE_DIR = Path(__file__).resolve().parent.parent
INPUT_FILE = BASE_DIR / "data" / "raw" / "household_power_consumption.txt"
OUTPUT_FILE = BASE_DIR / "data" / "processed" / "energia_limpio.csv"


# =========================
# FUNCIÓN PRINCIPAL
# =========================
def limpiar_dataset_energia():
    print("Leyendo dataset de energía...")

    # Leer archivo original
    # sep=';' porque el TXT usa punto y coma como separador
    # na_values='?' porque este dataset suele usar ? para valores faltantes
    df = pd.read_csv(
        INPUT_FILE,
        sep=";",
        na_values=["?"],
        low_memory=False
    )

    print(f"Registros originales: {len(df)}")
    print("Columnas detectadas:")
    print(df.columns.tolist())

    # =========================
    # UNIR FECHA Y HORA
    # =========================
    print("\nConstruyendo columna datetime...")
    df["datetime"] = pd.to_datetime(
        df["Date"] + " " + df["Time"],
        format="%d/%m/%Y %H:%M:%S",
        errors="coerce"
    )

    # Eliminar columnas originales de fecha y hora
    df.drop(columns=["Date", "Time"], inplace=True)

    # =========================
    # CONVERTIR VARIABLES A NUMÉRICO
    # =========================
    columnas_numericas = [
        "Global_active_power",
        "Global_reactive_power",
        "Voltage",
        "Global_intensity",
        "Sub_metering_1",
        "Sub_metering_2",
        "Sub_metering_3"
    ]

    print("\nConvirtiendo columnas numéricas...")
    for col in columnas_numericas:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # =========================
    # ELIMINAR FILAS CON DATETIME INVÁLIDO
    # =========================
    antes = len(df)
    df = df.dropna(subset=["datetime"])
    despues = len(df)
    print(f"Filas eliminadas por datetime inválido: {antes - despues}")

    # =========================
    # ORDENAR CRONOLÓGICAMENTE
    # =========================
    print("\nOrdenando datos por fecha...")
    df = df.sort_values("datetime").reset_index(drop=True)

    # =========================
    # REVISIÓN DE VALORES FALTANTES
    # =========================
    print("\nValores faltantes por columna antes de imputar:")
    print(df.isna().sum())

    # Interpolación temporal para no romper la serie
    print("\nAplicando interpolación temporal...")
    df = df.set_index("datetime")
    df[columnas_numericas] = df[columnas_numericas].interpolate(method="time")

    # Relleno extra por seguridad si quedó algo al inicio o final
    df[columnas_numericas] = df[columnas_numericas].bfill().ffill()

    df = df.reset_index()

    print("\nValores faltantes por columna después de imputar:")
    print(df.isna().sum())

    # =========================
    # GUARDAR RESULTADO
    # =========================
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)

    print(f"\nDataset limpio guardado en: {OUTPUT_FILE}")
    print("\nPrimeras filas del dataset limpio:")
    print(df.head())


if __name__ == "__main__":
    limpiar_dataset_energia()