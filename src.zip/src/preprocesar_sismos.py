import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
INPUT_FILE  = BASE_DIR / "data" / "processed" / "sismos_limpio.csv"
OUTPUT_FILE = BASE_DIR / "data" / "processed" / "sismos_serie_diaria.csv"

def main():
    print("=" * 55)
    print("  PREPROCESAMIENTO — Serie Diaria Sísmica")
    print("=" * 55)

    df = pd.read_csv(INPUT_FILE)
    df["time"] = pd.to_datetime(df["time"], format="mixed", utc=True)
    df["date"] = df["time"].dt.date
    df["date"] = pd.to_datetime(df["date"])

    # Agregación diaria
    serie = df.groupby("date").agg(
        avg_mag        = ("mag",   "mean"),
        max_mag        = ("mag",   "max"),
        avg_depth      = ("depth", "mean"),
        count_sismos   = ("mag",   "count")
    ).reset_index()

    # Rango completo de fechas sin huecos
    rango = pd.date_range(start=serie["date"].min(), end=serie["date"].max(), freq="D")
    serie = serie.set_index("date").reindex(rango)
    serie.index.name = "date"

    # ── CORRECCIÓN CLAVE ──────────────────────────────────────────
    # Los días sin sismos registrados NO son magnitud 0.
    # Se introduce una columna binaria y se imputa con NaN → forward fill
    # para no distorsionar la distribución con ceros artificiales.
    serie["hay_actividad"] = serie["count_sismos"].notna().astype(int)
    serie["count_sismos"]  = serie["count_sismos"].fillna(0).astype(int)

    # Para avg_mag y avg_depth: forward fill (propaga último valor conocido)
    # luego backward fill por si hay NaN al inicio
    serie["avg_mag"]   = serie["avg_mag"].ffill().bfill()
    serie["max_mag"]   = serie["max_mag"].ffill().bfill()
    serie["avg_depth"] = serie["avg_depth"].ffill().bfill()

    serie = serie.reset_index()

    print(f"Días totales en serie : {len(serie):,}")
    print(f"Días con actividad    : {serie['hay_actividad'].sum():,} ({serie['hay_actividad'].mean()*100:.1f}%)")
    print(f"Días sin actividad    : {(serie['hay_actividad']==0).sum():,}")
    print(f"avg_mag  — min: {serie['avg_mag'].min():.3f}  max: {serie['avg_mag'].max():.3f}")
    print(f"Columnas finales      : {serie.columns.tolist()}")

    serie.to_csv(OUTPUT_FILE, index=False)
    print(f"\n✅ Guardado en: {OUTPUT_FILE}\n")

if __name__ == "__main__":
    main()