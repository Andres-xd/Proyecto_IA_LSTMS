import pandas as pd
import numpy as np
import joblib
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler

BASE_DIR    = Path(__file__).resolve().parent.parent
INPUT_FILE  = BASE_DIR / "data" / "processed" / "sismos_serie_diaria.csv"
OUTPUT_FILE = BASE_DIR / "data" / "processed" / "sismos_normalizado.csv"
SCALER_FILE = BASE_DIR / "data" / "processed" / "scaler_sismos.pkl"

# Columnas que entran al modelo LSTM
FEATURE_COLS = ["avg_mag", "max_mag", "avg_depth", "count_sismos", "hay_actividad"]

def main():
    print("=" * 55)
    print("  NORMALIZACIÓN — Serie Sísmica")
    print("=" * 55)

    df = pd.read_csv(INPUT_FILE, parse_dates=["date"])

    print(f"Registros leídos : {len(df):,}")
    print(f"Features usadas  : {FEATURE_COLS}")

    fechas = df["date"]
    datos  = df[FEATURE_COLS].copy()

    # ── CORRECCIÓN: fit SOLO sobre train (80%) para evitar data leakage ──
    split = int(len(datos) * 0.8)
    scaler = MinMaxScaler()
    scaler.fit(datos.iloc[:split])                      # ajuste solo en train
    datos_norm = scaler.transform(datos)                # transform a todo

    df_norm = pd.DataFrame(datos_norm, columns=FEATURE_COLS)
    df_norm.insert(0, "date", fechas)

    # Guardar scaler y dataset normalizado
    df_norm.to_csv(OUTPUT_FILE, index=False)
    joblib.dump(scaler, SCALER_FILE)

    print(f"Rango normalizado avg_mag  : [{df_norm['avg_mag'].min():.3f}, {df_norm['avg_mag'].max():.3f}]")
    print(f"Rango normalizado avg_depth: [{df_norm['avg_depth'].min():.3f}, {df_norm['avg_depth'].max():.3f}]")
    print(f"\n✅ Normalizado guardado en : {OUTPUT_FILE}")
    print(f"✅ Scaler guardado en      : {SCALER_FILE}\n")

if __name__ == "__main__":
    main()
