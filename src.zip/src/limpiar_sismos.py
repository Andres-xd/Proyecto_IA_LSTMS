import pandas as pd
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RAW_FILE = BASE_DIR / "data" / "raw" / "Dataset_Sismología_Nuevo.csv"
PROCESSED_DIR = BASE_DIR / "data" / "processed"
PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
OUTPUT_FILE = PROCESSED_DIR / "sismos_limpio.csv"

def main():
    print("=" * 55)
    print("  LIMPIEZA — Dataset Sísmico")
    print("=" * 55)

    df = pd.read_csv(RAW_FILE)
    print(f"Registros originales : {len(df):,}")

    # Solo columnas útiles y confiables (sin columnas con >50% nulos)
    columnas_utiles = ["time", "latitude", "longitude", "depth", "mag"]
    df = df[columnas_utiles].copy()

    # Convertir tipos
    df["time"] = pd.to_datetime(df["time"], errors="coerce", utc=True)
    for col in ["latitude", "longitude", "depth", "mag"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Eliminar nulos
    antes = len(df)
    df = df.dropna()
    print(f"Eliminados por nulos : {antes - len(df):,}")

    # Filtros de calidad
    df = df[df["mag"] > 0]
    df = df[df["depth"] >= 0]
    df = df[df["depth"] <= 700]        # profundidad máxima realista
    df = df[df["mag"] <= 10]           # magnitud máxima posible

    # Filtro temporal: solo desde 1970 (datos más confiables y consistentes)
    df = df[df["time"] >= pd.Timestamp("1970-01-01", tz="UTC")]

    df = df.sort_values("time").reset_index(drop=True)

    print(f"Registros finales    : {len(df):,}")
    print(f"Rango temporal       : {df['time'].min().date()} → {df['time'].max().date()}")
    print(f"Magnitud — min: {df['mag'].min():.1f}  max: {df['mag'].max():.1f}  media: {df['mag'].mean():.2f}")
    print(f"Profundidad — min: {df['depth'].min():.1f}  max: {df['depth'].max():.1f}")

    df.to_csv(OUTPUT_FILE, index=False)
    print(f"\n✅ Guardado en: {OUTPUT_FILE}\n")

if __name__ == "__main__":
    main()
