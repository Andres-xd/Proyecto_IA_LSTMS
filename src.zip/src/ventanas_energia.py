import pandas as pd
import numpy as np
from pathlib import Path


# =========================
# CONFIGURACIÓN
# =========================
BASE_DIR = Path(__file__).resolve().parent.parent
INPUT_FILE = BASE_DIR / "data" / "processed" / "energia_normalizado.csv"
OUTPUT_X = BASE_DIR / "data" / "processed" / "X_energia.npy"
OUTPUT_Y = BASE_DIR / "data" / "processed" / "y_energia.npy"

WINDOW_SIZE = 60
TARGET_COL = "Global_active_power"


# =========================
# FUNCIÓN PARA CREAR VENTANAS
# =========================
def crear_ventanas(data, target_index, window_size):
    X = []
    y = []

    for i in range(len(data) - window_size):
        X.append(data[i:i + window_size])
        y.append(data[i + window_size, target_index])

    return np.array(X, dtype=np.float32), np.array(y, dtype=np.float32)


# =========================
# FUNCIÓN PRINCIPAL
# =========================
def generar_ventanas_energia():
    print("Leyendo dataset normalizado de energía...")
    df = pd.read_csv(INPUT_FILE, parse_dates=["datetime"])

    # Nos quedamos solo con las columnas numéricas
    columnas_features = [
        "Global_active_power",
        "Global_reactive_power",
        "Voltage",
        "Global_intensity",
        "Sub_metering_1",
        "Sub_metering_2",
        "Sub_metering_3"
    ]

    df_features = df[columnas_features].copy()

    print(f"Total de registros: {len(df_features)}")
    print("Columnas utilizadas:")
    print(columnas_features)

    # Convertir a matriz numpy
    data = df_features.values

    # Índice de la variable objetivo
    target_index = columnas_features.index(TARGET_COL)

    print(f"\nCreando ventanas deslizantes con tamaño {WINDOW_SIZE}...")
    X, y = crear_ventanas(data, target_index, WINDOW_SIZE)

    print("\nFormas generadas:")
    print(f"X shape: {X.shape}")
    print(f"y shape: {y.shape}")

    # Guardar archivos
    np.save(OUTPUT_X, X)
    np.save(OUTPUT_Y, y)

    print(f"\nArchivo X guardado en: {OUTPUT_X}")
    print(f"Archivo y guardado en: {OUTPUT_Y}")

    print("\nEjemplo de una muestra:")
    print(f"X[0] shape: {X[0].shape}")
    print(f"y[0]: {y[0]}")


if __name__ == "__main__":
    generar_ventanas_energia()