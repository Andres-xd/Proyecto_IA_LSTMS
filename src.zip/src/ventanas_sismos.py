import pandas as pd
import numpy as np
from pathlib import Path

BASE_DIR    = Path(__file__).resolve().parent.parent
INPUT_FILE  = BASE_DIR / "data" / "processed" / "sismos_normalizado.csv"
OUTPUT_X    = BASE_DIR / "data" / "processed" / "X_sismos.npy"
OUTPUT_Y    = BASE_DIR / "data" / "processed" / "y_sismos.npy"

WINDOW_SIZE = 14        # 14 días de contexto (mejor que 7 para capturar patrones)
TARGET_COL  = "avg_mag" # variable objetivo

def crear_ventanas(data, window_size, target_idx):
    X, y = [], []
    for i in range(len(data) - window_size):
        X.append(data[i:i + window_size])
        y.append(data[i + window_size, target_idx])
    return np.array(X, dtype=np.float32), np.array(y, dtype=np.float32)

def main():
    print("=" * 55)
    print("  VENTANAS DESLIZANTES — Sismología")
    print("=" * 55)

    df = pd.read_csv(INPUT_FILE, parse_dates=["date"])

    feature_cols = [c for c in df.columns if c != "date"]
    target_idx   = feature_cols.index(TARGET_COL)

    print(f"Features : {feature_cols}")
    print(f"Target   : {TARGET_COL} (índice {target_idx})")
    print(f"Window   : {WINDOW_SIZE} días")

    data = df[feature_cols].values.astype(np.float32)
    X, y = crear_ventanas(data, WINDOW_SIZE, target_idx)

    print(f"\nVentanas generadas : {len(X):,}")
    print(f"Forma X            : {X.shape}  → (muestras, timesteps, features)")
    print(f"Forma y            : {y.shape}")

    np.save(OUTPUT_X, X)
    np.save(OUTPUT_Y, y)
    print(f"\n✅ X guardado en: {OUTPUT_X}")
    print(f"✅ y guardado en: {OUTPUT_Y}\n")

if __name__ == "__main__":
    main()