import numpy as np
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
INPUT_X  = BASE_DIR / "data" / "processed" / "X_sismos.npy"
INPUT_Y  = BASE_DIR / "data" / "processed" / "y_sismos.npy"

OUTPUT_X_TRAIN = BASE_DIR / "data" / "processed" / "X_train_sismos.npy"
OUTPUT_X_VAL   = BASE_DIR / "data" / "processed" / "X_val_sismos.npy"
OUTPUT_X_TEST  = BASE_DIR / "data" / "processed" / "X_test_sismos.npy"
OUTPUT_Y_TRAIN = BASE_DIR / "data" / "processed" / "y_train_sismos.npy"
OUTPUT_Y_VAL   = BASE_DIR / "data" / "processed" / "y_val_sismos.npy"
OUTPUT_Y_TEST  = BASE_DIR / "data" / "processed" / "y_test_sismos.npy"

# División 70 / 15 / 15 (recomendado para datasets pequeños)
TRAIN_RATIO = 0.70
VAL_RATIO   = 0.15
# TEST_RATIO  = 0.15  (el resto)

def main():
    print("=" * 55)
    print("  SPLIT TEMPORAL — Sismología (70/15/15)")
    print("=" * 55)

    X = np.load(INPUT_X)
    y = np.load(INPUT_Y)

    n = len(X)
    train_end = int(n * TRAIN_RATIO)
    val_end   = int(n * (TRAIN_RATIO + VAL_RATIO))

    X_train, y_train = X[:train_end],      y[:train_end]
    X_val,   y_val   = X[train_end:val_end], y[train_end:val_end]
    X_test,  y_test  = X[val_end:],        y[val_end:]

    print(f"Total muestras : {n:,}")
    print(f"Train          : {len(X_train):,}  ({len(X_train)/n*100:.0f}%)")
    print(f"Validación     : {len(X_val):,}   ({len(X_val)/n*100:.0f}%)")
    print(f"Test           : {len(X_test):,}   ({len(X_test)/n*100:.0f}%)")

    np.save(OUTPUT_X_TRAIN, X_train);  np.save(OUTPUT_Y_TRAIN, y_train)
    np.save(OUTPUT_X_VAL,   X_val);    np.save(OUTPUT_Y_VAL,   y_val)
    np.save(OUTPUT_X_TEST,  X_test);   np.save(OUTPUT_Y_TEST,  y_test)

    print(f"\n✅ Splits guardados en data/processed/\n")

if __name__ == "__main__":
    main()
